---
name: health-guidance-and-records
description: "Use when managing health updates and giving safe guidance."
version: 1.0.0
---

# Health Guidance and Records

Use this skill for personal health updates, symptom tracking, medication-status updates, appointment/insurance logistics, and health guidance. Treat all health information as sensitive.

## Core approach

- Be professional, friendly, and appropriately concise.
- Do not diagnose from chat. State uncertainty and frame possible conditions as topics for clinical evaluation.
- Gather relevant details before giving a substantive assessment. Continue requesting information until the user indicates they are finished (for example, “done” or “that’s all I know”).
- Once the user is finished, give a practical next-step response rather than prolonging intake.
- Separate self-directed measures from provider-managed care. Include both whenever giving treatment guidance.
- Call out the realistic risks of inaction, overuse, medication changes, and delayed evaluation without catastrophizing.
- Address emotional health, family/support-system safety, sleep, nutrition, low-vice choices, and pain-neutral activity alongside physical symptoms.

## Health memory workflow

1. Read the current health profile memory and any user-authorized external health-memory sources.
2. Preserve provenance: distinguish an event’s stated date/time from when a source was retrieved. Do not infer an exact time from a date-only entry.
3. Reconcile duplicates and contradictions. Prefer the newer, more specific user statement; retain important uncertainty such as unknown prescriber supervision.
4. Save only durable, decision-relevant facts. Do not store speculative diagnoses, transient emotional wording, or full narratives.
5. For every durable event memory, prepend an explicit CST timestamp in the form `YYYY-MM-DD HH:mm CST —`. If exact timing is unavailable, begin with `Timestamp unknown (event dated YYYY-MM-DD) CST —` or clearly label the date as approximate.
6. After saving, briefly confirm what was recorded and identify any operational next step (appointment, authorization, clinician follow-up).

## Medication changes

- Record a medication start, stop, taper, or completed taper precisely, including what is unknown: indication, dose, prescriber awareness, instructions, and supervision.
- Do not provide individualized dosing, tapering, or substitution instructions.
- Encourage prompt prescriber contact after unsupervised or unclear changes, while respecting the user’s autonomy.
- For PRN sedating medications, advise use only as prescribed; flag sedation, driving/decision impairment, and unsafe combinations such as alcohol, opioids, cannabis, or other sedatives unless a prescriber/pharmacist has confirmed safety.
- Give urgent escalation guidance for severe mood changes, sustained decreased need for sleep with agitation, psychosis/confusion, or thoughts of self-harm or harm to others.

## Musculoskeletal symptoms and imaging logistics

- Record location, laterality, severity, function, onset, triggers, relieving factors, prior injury/dislocation, neurologic symptoms, and what exercise/loading is tolerated.
- Recommend relative rest rather than complete immobilization unless a clinician directs otherwise. Favor general conditioning and pain-neutral movement; stop repeated provocative “testing.”
- Encourage clinician/PT-directed rehabilitation. Do not prescribe a generic strengthening routine when it causes pain or the diagnosis is unresolved.
- For imaging delayed by authorization, preserve the scheduled appointment, ask the imaging center for cancellation-list access across acceptable locations/times, and ask the ordering office to verify supporting records and request details.
- Escalate urgently for deformity after trauma, true dislocation, sudden marked weakness, inability to raise the arm, persistent/spreading numbness, cold/pale limb, fever/redness/warmth with escalating pain, or cardiopulmonary symptoms.

## Sensitive messaging channels

- Before configuring a health profile on a messenger, explain that access must be restricted; obtain or reuse a confirmed owner account ID rather than leaving the bot open to all users.
- Give a brief progress update before pausing at an interactive security prompt, naming the exact information needed to continue.
- Keep a separate bot credential for each simultaneously active profile. A token already used by another profile gateway must not be reused; resolve the token assignment before starting the health gateway.

## Documentation style

- Use a short, clinician-useful symptom list when preparing for PT, imaging, or an office call.
- Label reported facts as reported; do not overstate a causal link or an imaging need.
- Keep a clear distinction between completed facts, plans, and pending insurance/authorization decisions.
